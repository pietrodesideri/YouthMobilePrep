var questions = [
  {
    "question": "In how many ways do we write CSS",
    "option1": "one",
    "option2": "four",
    "option3": "three",
    "option4": "five",
    "answer": "3"
  },
  {
    "question": "CSS is an acronym for..",
    "option1": "Case Style Sheet",
    "option2": "Cascading Style Sheet",
    "option3": "Casding Style Sheet",
    "option4": "Casett Style Sheet",
    "answer": "2"

  },
  {
    "question": "Which of the following statement is true",
    "option1": "CSS is a markup language",
    "option2": "HTML adds interactivity to web pages",
    "option3": "JavaScript is a programming language",
    "option4": "CSS is a programming language",
    "answer": "3"
  },
  {
    "question": "All of the following are true except..",
    "option1": "Inline-styling",
    "option2": "Embedded styling",
    "option3": "External styling",
    "option4": "Intra-styling",
    "answer": "4"
  },
  {
    "question": "The CSS declaration consist of the following except",
    "option1": "property",
    "option2": "selector",
    "option3": "value",
    "option4": "Alphabet",
    "answer": "4"
  },
  {
    "question": "In CSS, an ID is called using..",
    "option1": "#",
    "option2": "/",
    "option3": "@",
    "option4": "?",
    "answer": "1"
  },
  {
    "question": "Which of the following is a CSS selector",
    "option1": "selecting by tag name",
    "option2": "list selector",
    "option3": "null selector",
    "option4": "undefined selector",
    "answer": "1"
  },
  {
    "question": "Embedded CSS is written in..",
    "option1": "the body tag",
    "option2": "head tag",
    "option3": "title tag",
    "option4": "none of these",
    "answer": "2"
  },
  {
    "question": "Which of the following statement is true about CSS",
    "option1": "It is a markup language",
    "option2": "It is styling language",
    "option3": "It is a programming language",
    "option4": "It is also called Java",
    "answer": "2"
  },
  {
    "question": "All the following are procedures for styling html elemenets except",
    "option1": "creating an element",
    "option2": "defining an element",
    "option3": "calling the element",
    "option4": "undoing the element",
    "answer": "4"
  },
  {
    "question": "What is the correct syntax for refering to an external style sheet",
    "option1": "<stylesheet>mystyle.css</stylesheet>",
    "option2": "<stylesheet src='mystyle.css'>",
    "option3": "<link rel='stylesheet' type='text/css' href='mystyle.css'",
    "option4": "none of these",
    "answer": "3"
  }
]