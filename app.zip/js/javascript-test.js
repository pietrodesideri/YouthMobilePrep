var questions = [
  {
    "question": "single line comments are written as..",
    "option1": "//",
    "option2": "/",
    "option3": "///",
    "option4": "##",
    "answer": "1"
  },
  {
    "question": "Choose the correct statement",
    "option1": "Javascript is case sensitive",
    "option2": "javascript is not case sensitive",
    "option3": "javascript is same as java",
    "option4": "javascript is another name for HTML",
    "answer": "1"

  },
  {
    "question": "Which of the following statement is true",
    "option1": "CSS is a markup language",
    "option2": "HTML adds interactivity to web pages",
    "option3": "JavaScript is a programming language",
    "option4": "CSS is a programming language",
    "answer": "3"
  },
  {
    "question": "All of the following are true except..",
    "option1": "Inline-javascript",
    "option2": "Embedded javascript",
    "option3": "External javascript",
    "option4": "javascript is a programming language",
    "answer": "1"
  },
  {
    "question": "Javascript data types include the following except",
    "option1": "String",
    "option2": "Boolean",
    "option3": "Number",
    "option4": "Alphabet",
    "answer": "4"
  },
  {
    "question": "Multi line comment is written as..",
    "option1": "/**/",
    "option2": "/",
    "option3": "@",
    "option4": "?",
    "answer": "1"
  },
  {
    "question": "Which of the following variable takes precedence if variable names are the same",
    "option1": "global variable",
    "option2": "local variable",
    "option3": "both of the above",
    "option4": "none of the above",
    "answer": "2"
  },
  {
    "question": "Javscript objects have...",
    "option1": "properties",
    "option2": "elements",
    "option3": "child-elements",
    "option4": "child-properties",
    "answer": "1"
  },
  {
    "question": "What is JavaScript?",
    "option1": "It is a markup language",
    "option2": "It is styling language",
    "option3": "It is a programming language",
    "option4": "It is also called Java",
    "answer": "3"
  },
  {
    "question": "JavaScript is also known as?",
    "option1": "EdmaScript",
    "option2": "EmaScript",
    "option3": "Escript",
    "option4": "EcmaScript",
    "answer": "4"
  },
  {
    "question": "Variables are declared using the keyword called...",
    "option1": "now",
    "option2": "then",
    "option3": "var",
    "option4": "this",
    "answer": "3"
  }
]