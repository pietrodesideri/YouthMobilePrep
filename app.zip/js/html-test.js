var questions = [
  {
    "question": "Hypertext Markup Language is also called",
    "option1": "HML",
    "option2": "CSS",
    "option3": "HTML",
    "option4": "None of the Above",
    "answer": "3"
  },
  {
    "question": "The self closing tag is also called..",
    "option1": "start tag",
    "option2": "void element",
    "option3": "end tag",
    "option4": "opening tag",
    "answer": "2"

  },
  {
    "question": "Which of the following statement is true",
    "option1": "HTML is not a markup language",
    "option2": "HTML is used to build structure of web pages",
    "option3": "JavaScript is a styling language",
    "option4": "CSS is a programming language",
    "answer": "2"
  },
  {
    "question": "All of the following are true except..",
    "option1": "html attributes appear in the start tag",
    "option2": "html attributes are in key/value pairs",
    "option3": "the title tag is not an html element",
    "option4": "the anchor tag links html documents",
    "answer": "3"
  },
  {
    "question": "HTML comments are important because...",
    "option1": "they guide developers",
    "option2": "only users see the comments",
    "option3": "they are displayed in the browser",
    "option4": "none of the above",
    "answer": "1"
  },
  {
    "question": "Which of the following is a text formating tag",
    "option1": "em",
    "option2": "p",
    "option3": "div",
    "option4": "a",
    "answer": "1"
  },
  {
    "question": "HTML pages are linked using one of the following",
    "option1": "anchor/a tag",
    "option2": "image tag",
    "option3": "div tag",
    "option4": "span tag",
    "answer": "1"
  },
  {
    "question": "Which of the following is not a heading tag",
    "option1": "h4",
    "option2": "h6",
    "option3": "h2",
    "option4": "h7",
    "answer": "4"
  },
  {
    "question": "Which of the following tags is not a component of the html table",
    "option1": "table",
    "option2": "th",
    "option3": "tc",
    "option4": "td",
    "answer": "3"
  },
  {
    "question": "The ol tag is also called",
    "option1": "over list",
    "option2": "oval list",
    "option3": "other list",
    "option4": "ordered list",
    "answer": "4"
  },
  {
    "question": "Which of the following is true of HTML attributes?",
    "option1": "provides link to CSS files",
    "option2": "Link HTML files to JavaScript files",
    "option3": "Provides additional information about HTML elements",
    "option4": "Provides additional information about HTML and CSS",
    "answer": "3"
  }
]